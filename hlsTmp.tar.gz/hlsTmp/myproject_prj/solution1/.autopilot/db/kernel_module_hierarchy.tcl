set ModuleHierarchy {[{
"Name" : "myproject","ID" : "0","Type" : "pipeline",
"SubInsts" : [
	{"Name" : "call_ret2_concatenate1d_ap_fixed_ap_fixed_ap_fixed_16_6_5_3_0_config3_s_fu_57","ID" : "1","Type" : "pipeline"},
	{"Name" : "call_ret3_dense_latency_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config4_s_fu_65","ID" : "2","Type" : "pipeline"},
	{"Name" : "call_ret_relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_4_0_0_relu_config6_s_fu_83","ID" : "3","Type" : "pipeline"},
	{"Name" : "grp_dense_latency_ap_ufixed_8_0_4_0_0_ap_fixed_16_6_5_3_0_config7_s_fu_129","ID" : "4","Type" : "pipeline"},]
}]}