set SynModuleInfo {
  {SRCNAME concatenate1d<ap_fixed,ap_fixed,ap_fixed<16,6,5,3,0>,config3> MODELNAME concatenate1d_ap_fixed_ap_fixed_ap_fixed_16_6_5_3_0_config3_s RTLNAME myproject_concatenate1d_ap_fixed_ap_fixed_ap_fixed_16_6_5_3_0_config3_s}
  {SRCNAME {dense_latency<ap_fixed<16, 6, 5, 3, 0>, ap_fixed<16, 6, 5, 3, 0>, config4>} MODELNAME dense_latency_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config4_s RTLNAME myproject_dense_latency_ap_fixed_16_6_5_3_0_ap_fixed_16_6_5_3_0_config4_s}
  {SRCNAME {relu<ap_fixed<16, 6, 5, 3, 0>, ap_ufixed<8, 0, 4, 0, 0>, relu_config6>} MODELNAME relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_4_0_0_relu_config6_s RTLNAME myproject_relu_ap_fixed_16_6_5_3_0_ap_ufixed_8_0_4_0_0_relu_config6_s}
  {SRCNAME {dense_latency<ap_ufixed<8, 0, 4, 0, 0>, ap_fixed<16, 6, 5, 3, 0>, config7>} MODELNAME dense_latency_ap_ufixed_8_0_4_0_0_ap_fixed_16_6_5_3_0_config7_s RTLNAME myproject_dense_latency_ap_ufixed_8_0_4_0_0_ap_fixed_16_6_5_3_0_config7_s}
  {SRCNAME myproject MODELNAME myproject RTLNAME myproject IS_TOP 1}
}
